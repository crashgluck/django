from asyncio.windows_events import NULL
from django.shortcuts import render, redirect
from .models import Contacto
from .forms import ContactoForm
from django.contrib import messages
#from django.http import HttpResponse
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.db.models import Q


def buscar_contactos(search):
    # Dividir el término de búsqueda en palabras usando guiones como separadores
    search_terms = search.split('-')

    # Crear una lista de condiciones Q para cada palabra en lote y n_lote
    conditions = [
        Q(lote__icontains=term) | Q(n_lote__icontains=term)
        for term in search_terms
    ]

    # Aplicar la condición OR entre las condiciones para cada palabra
    return Contacto.objects.filter(
        Q(name__icontains=search) | Q(*conditions)
    )

def index(request, letter=None):
    search_query = request.GET.get('search', '')

    if letter:
        search_term = letter + search_query
    else:
        search_term = search_query

    contacts = buscar_contactos(search_term)

    # Número de elementos por página
    items_por_pagina = 50

    # Crear un objeto Paginator
    paginator = Paginator(contacts, items_por_pagina)

    # Obtener el número de página actual desde la solicitud GET
    page = request.GET.get('page')

    try:
        # Obtener los contactos para la página actual
        contacts = paginator.page(page)
    except PageNotAnInteger:
        # Si la página no es un número entero, mostrar la primera página
        contacts = paginator.page(1)
    except EmptyPage:
        # Si la página está fuera de rango (por ejemplo, 9999), mostrar la última página
        contacts = paginator.page(paginator.num_pages)

    context = {'contacts': contacts}

    return render(request, 'contacto/index.html', context)

def view(request, id):
    contact = Contacto.objects.get(id=id)
    context = {
        'contact': contact
    }
    return render(request, 'contacto/detail.html', context)

def edit(request,id):

    contact = Contacto.objects.get(id=id)

    if(request.method == 'GET'):        
        form = ContactoForm(instance= contact)#buena forma fue pasar la instancia en vez de initial 
        context = {
            'form': form,
            'id': id
        }
        return render(request, 'contacto/edit.html', context)
    
    if(request.method == 'POST'):
        form = ContactoForm(request.POST, instance = contact)
        form.save()
        if form.is_valid():
            form.save()
            context = {
            'form': form,
            'id': id
        }
        messages.success(request, 'Contacto Actualizado!')
        return render(request, 'contacto/edit.html', context)
    
def create(request):
    if (request.method == 'GET'):
        form = ContactoForm
        context = {
            'form':form
        }
        return render(request, 'contacto/create.html', context)
    
    if request.method == 'POST':
        form = ContactoForm(request.POST)
        if form.is_valid:
            form.save()
        return redirect('contacto')

def delete(request, id):
    contact = Contacto.objects.get(id=id)
    contact.delete()

    return redirect('contacto')
