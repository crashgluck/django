from django.db import models
from datetime import date

class Contacto(models.Model):
    name = models.CharField(
        max_length=100,
        null=False,
        blank=False
        )
        
    phone = models.CharField(
        max_length=100, #para incluir codigo area +569
        null=True,
        blank=True
    )
    mobile = models.CharField(
        max_length=100,
        null=True,
        blank=True
    )
    email = models.EmailField(
        null=True,
        blank=False
    )
    lote = models.CharField(
        max_length=3, 
        null=False,
        blank=False
    )
    n_lote = models.CharField(
        max_length=3, 
        null=False,
        blank=False
    )
    rut = models.CharField(
        max_length=11, 
        null=True,
        blank=False
    )
    date = models.DateField(
        default=date.today,
        null = True
        )    


    def __str__(self):
        return self.name
# Create your models here.
