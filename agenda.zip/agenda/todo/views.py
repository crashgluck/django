from django.shortcuts import render, redirect
from .models import Todo
from .forms import TodoForm
from django.contrib import messages
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger


def index(request):
    todos =  Todo.objects.filter(title__contains=request.GET.get('search',''))

    # Número de elementos por página
    items_por_pagina = 40

    # Crear un objeto Paginator
    paginator = Paginator(todos, items_por_pagina)

    # Obtener el número de página actual desde la solicitud GET
    page = request.GET.get('page')

    try:
        # Obtener los contactos para la página actual
        todos = paginator.page(page)
    except PageNotAnInteger:
        # Si la página no es un número entero, mostrar la primera página
        todos = paginator.page(1)
    except EmptyPage:
        # Si la página está fuera de rango (por ejemplo, 9999), mostrar la última página
        todos = paginator.page(paginator.num_pages)
    context = {
        'todos': todos
    }
    return render(request, 'todo/index.html', context)

def view(request, id):
    todo = Todo.objects.get(id=id)
    context = {
        'todo': todo
    }
    return render(request, 'todo/detail.html', context)


def edit(request, id):
    todo = Todo.objects.get(id=id)

    if request.method == 'GET':
        form = TodoForm(instance=todo)
        context = {
            'form': form,
            'id': id
        }
        return render(request, 'todo/edit.html', context)
    if request.method == 'POST':
        form = TodoForm(request.POST, instance=todo)
        if form.is_valid():
            form.save()
        messages.success(request, 'Tarea Actualizada!')
        context = {
            'form' : form,
            'id' : id
        }
        return render(request, 'todo/edit.html', context)

        

def create(request):
    if request.method == 'GET':
        form = TodoForm()
        context = {
            'form': form
        }
        return render(request, 'todo/create.html', context)
    if request.method == 'POST':
        form = TodoForm(request.POST)
        if form.is_valid():
            form.save()
        return redirect('todo')

def delete(request, id):    
    todo = Todo.objects.get(id=id)
    todo.delete()

    return redirect('todo')
# Create your views here.
